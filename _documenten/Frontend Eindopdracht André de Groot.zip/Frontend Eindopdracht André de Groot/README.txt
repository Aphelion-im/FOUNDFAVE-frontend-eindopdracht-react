Beste examinator,

De links naar Github, Figma, etc. kun je vinden in beide PDF documenten in het Colofon gedeelte.

Met vriendelijke groet,
André de Groot