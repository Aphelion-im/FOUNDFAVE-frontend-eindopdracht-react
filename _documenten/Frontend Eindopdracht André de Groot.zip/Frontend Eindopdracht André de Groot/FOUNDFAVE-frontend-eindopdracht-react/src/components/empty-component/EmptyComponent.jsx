export default function EmptyComponent() {
  return <></>;
}
